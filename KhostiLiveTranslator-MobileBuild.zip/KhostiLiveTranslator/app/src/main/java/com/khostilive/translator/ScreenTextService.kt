package com.khostilive.translator

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ScreenTextService : AccessibilityService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val client = OkHttpClient.Builder().callTimeout(35, TimeUnit.SECONDS).build()
    private lateinit var wm: WindowManager
    private var bubble: Button? = null
    private var resultView: TextView? = null
    private var resultWindow: LinearLayout? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* no continuous collection; capture only on button tap */ }
    override fun onInterrupt() {}

    private fun windowType(): Int = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE

    private fun showBubble() {
        if (bubble != null) return
        val b = Button(this).apply {
            text = "ترجمه"
            textSize = 12f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(23, 105, 170))
            setOnClickListener { translateVisibleText() }
        }
        val p = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, windowType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL; x = 12; y = 0
        }
        try { wm.addView(b, p); bubble = b } catch (_: Exception) { }
    }

    private fun collectText(node: AccessibilityNodeInfo?, out: LinkedHashSet<String>, depth: Int = 0) {
        if (node == null || depth > 35 || out.size > 120) return
        val t = node.text?.toString()?.trim().orEmpty()
        if (t.length > 1 && t !in out) out.add(t)
        val d = node.contentDescription?.toString()?.trim().orEmpty()
        if (d.length > 1 && d !in out) out.add(d)
        for (i in 0 until node.childCount) collectText(node.getChild(i), out, depth + 1)
    }

    private fun translateVisibleText() {
        val root = rootInActiveWindow
        val parts = LinkedHashSet<String>()
        collectText(root, parts)
        root?.recycle()
        val source = parts.joinToString("\n").take(4500)
        if (source.isBlank()) { showResult("متنی پیدا نشد. ممکن است این برنامه متن صفحه را به دسترس‌پذیری نشان ندهد."); return }
        val key = getSharedPreferences("translator", MODE_PRIVATE).getString("api_key", "").orEmpty()
        if (key.isBlank()) { showResult("اول کلید Google Cloud Translation API را در برنامه وارد و ذخیره کن."); return }
        showResult("در حال ترجمه…")
        scope.launch(Dispatchers.IO) {
            val translated = try { googleTranslate(source, key) } catch (e: Exception) { "خطا در ترجمه: ${e.message ?: "اتصال یا کلید API را بررسی کن"}" }
            launch(Dispatchers.Main) { showResult(translated) }
        }
    }

    private fun googleTranslate(text: String, key: String): String {
        val json = JSONObject().put("q", text).put("source", "ps").put("target", "fa").put("format", "text")
        val body = json.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
        val req = Request.Builder().url("https://translation.googleapis.com/language/translate/v2?key=$key").post(body).build()
        client.newCall(req).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IllegalStateException("HTTP ${response.code}: $raw")
            val data = JSONObject(raw).getJSONObject("data").getJSONArray("translations")
            return data.getJSONObject(0).getString("translatedText").replace("&quot;", "\"").replace("&#39;", "'").replace("&amp;", "&")
        }
    }

    private fun showResult(text: String) {
        if (bubble == null) showBubble()
        if (resultWindow == null) {
            val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 14, 18, 14); setBackgroundColor(Color.WHITE) }
            val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            header.addView(TextView(this).apply { this.text = "ترجمه به دری"; textSize = 18f; setTextColor(Color.BLACK) }, LinearLayout.LayoutParams(0, -2, 1f))
            header.addView(Button(this).apply { this.text = "بستن"; setOnClickListener { removeResult() } })
            layout.addView(header)
            val scroll = ScrollView(this)
            resultView = TextView(this).apply { textSize = 17f; setTextColor(Color.DKGRAY); setTextIsSelectable(true); setPadding(4, 12, 4, 12) }
            scroll.addView(resultView)
            layout.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
            resultWindow = layout
            val p = WindowManager.LayoutParams((resources.displayMetrics.widthPixels * .9).toInt(), (resources.displayMetrics.heightPixels * .55).toInt(), windowType(), WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.CENTER }
            try { wm.addView(layout, p) } catch (_: Exception) { resultWindow = null; resultView = null; return }
        }
        resultView?.text = text
    }

    private fun removeResult() {
        try { resultWindow?.let { wm.removeView(it) } } catch (_: Exception) { }
        resultWindow = null; resultView = null
    }

    override fun onDestroy() {
        removeResult()
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) { }
        bubble = null
        super.onDestroy()
    }
}
