package com.khostilive.translator

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("translator", MODE_PRIVATE)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 40, 28, 28); gravity = Gravity.CENTER_HORIZONTAL }
        box.addView(TextView(this).apply { text = "Khosti Live Translator\n\nترجمه نوشته‌های پشتو به دری"; textSize = 22f; gravity = Gravity.CENTER })
        box.addView(TextView(this).apply { text = "کلید Google Cloud Translation API را وارد کن:"; textSize = 15f; setPadding(0, 28, 0, 8) })
        val key = EditText(this).apply { hint = "API key"; setSingleLine(true); setText(prefs.getString("api_key", "")) }
        box.addView(key, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        box.addView(Button(this).apply { text = "ذخیره کلید"; setOnClickListener { prefs.edit().putString("api_key", key.text.toString().trim()).apply(); Toast.makeText(this@MainActivity, "ذخیره شد", Toast.LENGTH_SHORT).show() } })
        box.addView(Button(this).apply { text = "فعال‌کردن دکمه شناور"; setOnClickListener {
            if (!Settings.canDrawOverlays(this@MainActivity)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            else Toast.makeText(this@MainActivity, "اکنون دسترسی خواندن صفحه را در تنظیمات دسترس‌پذیری فعال کن.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } })
        box.addView(TextView(this).apply { text = "روش استفاده: دسترسی برنامه را فعال کن؛ به صفحه پیام پشتو برو؛ دکمه شناور «ترجمه» را بزن. فقط متن قابل‌خواندن صفحه پردازش می‌شود."; textSize = 14f; setPadding(0, 24, 0, 0) })
        setContentView(box)
    }
}
